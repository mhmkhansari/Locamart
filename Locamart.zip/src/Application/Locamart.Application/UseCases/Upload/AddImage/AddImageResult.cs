﻿namespace Locamart.Application.UseCases.Upload.AddImage;

public record AddImageResult
{
    public string Url { get; set; }
}

