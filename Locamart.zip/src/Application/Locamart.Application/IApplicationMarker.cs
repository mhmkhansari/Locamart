﻿
namespace Locamart.Application;

public interface IApplicationMarker
{

}

