﻿namespace Locamart.Adapter.ObjectStorage;

public class ObjectStorageOptions
{
    public string ProductBucketName { get; set; }
    public string BaseUrl { get; set; }
}

